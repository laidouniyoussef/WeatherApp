import SwiftUI

struct NewCityView: View {
    @State private var search: String = ""
    @State private var isValidating: Bool = false
    @State private var places: [GeocodingPlace] = []
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var cityStore: CityStore

    var body: some View {
        NavigationView {
            List {
                Section {
                    TextField("Search City", text: $search)
                        .onChange(of: search) { _ in
                            self.searchForCity()
                        }
                }

                Section {
                    ForEach(places) { place in
                        Text(place.name)
                            .onTapGesture {
                                self.handlePlaceSelection(place)
                            }
                    }
                }
            }
            .disabled(isValidating)
            .navigationBarTitle(Text("Add City"))
            .navigationBarItems(leading: cancelButton)
            .listStyle(GroupedListStyle())
        }
    }

    private var cancelButton: some View {
        Button(action: {
            self.presentationMode.wrappedValue.dismiss()
        }) {
            Text("Cancel")
        }
    }

    private func searchForCity() {
        print("Searching for city...")
        GeocodingManager.validateCity(withName: search) { places in
            DispatchQueue.main.async {
                self.places = places
            }
        }
    }

    private func handlePlaceSelection(_ place: GeocodingPlace) {
        let newCity = City(id: place.id, name: place.name, latitude: place.latitude, longitude: place.longitude)
        self.cityStore.cities.append(newCity)
        self.presentationMode.wrappedValue.dismiss()
    }
}
