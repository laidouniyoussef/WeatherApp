import SwiftUI

struct CityHourlyView: View {

    @ObservedObject var city: City

    private let rowHeight: CGFloat = 110

    var body: some View {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(filteredHourlyData) { hour in
                        VStack(spacing: 16) {
                            Text(hour.time.formattedHour)
                                .font(.footnote)
                            Image(systemName: weatherIcon(for: hour.temperature, rain: hour.rain))
                                .font(.body)
                            Text(String(format: "%.1f°C", hour.temperature))
                                .font(.headline)
                            Text(String(format: "%.1f mm", hour.rain))
                                .font(.caption)
                        }
                    }

                }
                .padding([.trailing, .leading])
            }
            .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0))
            .padding([.top, .bottom])
        }

    private var filteredHourlyData: [Hourly] {
        guard let hourlyData = city.weather?.hourly else {
            return []
        }

        let currentDate = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        let currentDateString = formatter.string(from: currentDate)

        return hourlyData.time.indices.compactMap { index in
            guard index < hourlyData.time.count else {
                return nil
            }

            let hourTime = hourlyData.time[index]
            let temperature = hourlyData.temperature_2m[index]
            let rain = hourlyData.rain[index]

            guard let date = formatter.date(from: hourTime),
                  date > currentDate,
                  date < currentDate.addingTimeInterval(24 * 60 * 60) else {
                return nil
            }

            return Hourly(time: hourTime, temperature: temperature, rain: rain)
        }
    }
    
    private func weatherIcon(for temperature: Double, rain: Double) -> String {
        if temperature > 10 && rain == 0 {
            return "sun.max.fill"
        } else if temperature < 10 && rain == 0  {
            return "cloud.fill"
        } else if rain > 0 {
            return "cloud.heavyrain.fill"
        } else if temperature > 10 && rain > 0 {
            return "cloud.sun.rain.fill"
        } else {
            return "sun.max.fill" // Default icon
        }
    }



}

extension String {
    var formattedHour: String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        if let date = dateFormatter.date(from: self) {
            dateFormatter.dateFormat = "HH:mm"
            return dateFormatter.string(from: date)
        }
        return self
    }
}

struct Hourly: Identifiable {
    let id = UUID()
    let time: String
    let temperature: Double
    let rain: Double
}
