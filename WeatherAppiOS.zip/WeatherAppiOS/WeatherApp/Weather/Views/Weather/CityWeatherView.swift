import SwiftUI

struct CityWeatherView : View {
    
    @ObservedObject var city: City
    
    var body: some View {
        
        List {
            Section(header: Text("Now")) {
                CityHeaderView(city: city)
            }
            
            Section(header: Text("Hourly")) {
                CityHourlyView(city: city)
            }
            
            Section(header: Text("Daily")) {
                            if let dailyData = city.weather?.hourly {
                                CityDailyView(hourlyData: dailyData)
                            } else {
                                Text("No daily data available")
                            }
                        }
        }
        .navigationBarTitle(Text(city.name))
    }
    
    
}
