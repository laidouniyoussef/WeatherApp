import SwiftUI
struct CityHeaderView: View {
    
    @ObservedObject var city: City
    
    var currentTemperature: String {
        guard let weather = city.weather?.hourly else {
            return "-ºC"
        }
        
        let temperature = weather.temperature_2m.first ?? 0
        let isRaining = weather.rain.first ?? 0 > 0
        
        var temperatureString = "\(temperature.formattedTemperature) -"
        
        
            let rainString = String(format: "%.1f mm", weather.rain.first ?? 0)
            temperatureString += " \(rainString)"
        
        
        return temperatureString
    }
    
    var currentWeatherIcon: String {
        guard let weather = city.weather?.hourly else {
            return "sun.max.fill"
        }
        
        let isRaining = weather.rain.first ?? 0 > 0
        let temperature = weather.temperature_2m.first ?? 0
        
        if temperature > 10 && !isRaining {
            return "sun.max.fill"
        } else if temperature < 10 {
            return "cloud.fill"
        } else if isRaining {
            return "cloud.heavyrain.fill"
        } else if temperature > 10 && isRaining {
            return "cloud.sun.rain.fill"
        } else {
            return "sun.max.fill"
        }
    }

    
    var body: some View {
        HStack(alignment: .center) {
            Spacer()
            HStack(alignment: .center, spacing: 16) {
                Image(systemName: currentWeatherIcon)
                    .font(.largeTitle)
                Text(currentTemperature)
                    .font(.largeTitle)
            }
            Spacer()
        }
        .frame(height: 110)
    }
}
