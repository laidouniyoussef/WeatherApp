import SwiftUI

let currentDayIndex = Calendar.current.component(.weekday, from: Date()) - 1
let dayNames = Array(Calendar.current.shortWeekdaySymbols[currentDayIndex...] + Calendar.current.shortWeekdaySymbols[..<currentDayIndex])

struct CityDailyView: View {
    @State var hourlyData: WeatherForecast.Hourly

    var body: some View {
        VStack {
            let dailyAverages = calculateDailyAverages()

            ForEach(0..<dailyAverages.count, id: \.self) { index in
                DailyItemView(dayIndex: index, hourlyData: hourlyData, dayName: dayNames[index])
            }
        }
    }

    private func calculateDailyAverages() -> [Double] {
        var dailyAverages: [Double] = []

        let dataPointsPerDay = 24
        let numberOfDays = hourlyData.time.count / dataPointsPerDay

        for dayIndex in 0..<numberOfDays {
            let startIndex = dayIndex * dataPointsPerDay
            let endIndex = startIndex + dataPointsPerDay
            let temperaturesForDay = Array(hourlyData.temperature_2m[startIndex..<endIndex])
            let averageTemperature = temperaturesForDay.reduce(0.0, +) / Double(dataPointsPerDay)
            dailyAverages.append(averageTemperature)
        }

        return dailyAverages
    }
}

struct DailyItemView: View {
    let dayIndex: Int
    let hourlyData: WeatherForecast.Hourly
    let dayName: String

    var body: some View {
        ZStack {
            HStack(alignment: .center) {
                Text(dayName)
                Spacer()
                Image(systemName: weatherIcon())
                    .font(.body)
                Spacer()
                Text(" \(calculateAverageTemperature().formattedTemperature) -")
                    .font(.footnote)
                Text("\(calculateAverageRain().formattedRain)")
                    .font(.footnote)
            }
        }
    }

    private func calculateAverageTemperature() -> Double {
        let startIndex = dayIndex * 24
        let endIndex = startIndex + 24
        let temperaturesForDay = Array(hourlyData.temperature_2m[startIndex..<endIndex])
        return temperaturesForDay.reduce(0.0, +) / Double(temperaturesForDay.count)
    }

    private func calculateAverageRain() -> Double {
        let startIndex = dayIndex * 24
        let endIndex = startIndex + 24
        let rainForDay = Array(hourlyData.rain[startIndex..<endIndex])
        return rainForDay.reduce(0.0, +) / Double(rainForDay.count)
    }

    private func weatherIcon() -> String {
        let averageTemperature = calculateAverageTemperature()
        let averageRain = calculateAverageRain()

        if averageTemperature > 10 && averageRain == 0 {
            return "sun.max.fill"
        } else if averageTemperature < 10 {
            return "cloud.fill"
        } else if averageRain > 5 {
            return "cloud.heavyrain.fill"
        } else if averageTemperature > 10 && averageRain > 0 {
            return "cloud.sun.rain.fill"
        } else {
            return "sun.max.fill"
        }
    }
}

extension Double {
    var formattedTemperature: String {
        return String(format: "%.1f °C", self)
    }

    var formattedRain: String {
        return String(format: "%.1f mm", self)
    }
}

