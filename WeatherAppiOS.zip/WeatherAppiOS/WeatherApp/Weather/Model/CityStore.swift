import Foundation

class CityStore: ObservableObject {
    @Published var cities: [City] = []
}
