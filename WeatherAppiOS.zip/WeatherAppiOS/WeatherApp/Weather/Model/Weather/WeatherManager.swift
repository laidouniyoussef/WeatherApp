    import UIKit


    class WeatherManager: NSObject {
        
        
        static func getWeatherForecast(latitude: Double, longitude: Double, completion: @escaping (_ result: WeatherForecast?) -> Void) {
            guard let url = URL(string: NetworkManager.APIURL.weatherForecastRequest(latitude: latitude, longitude: longitude)) else {
                completion(nil)
                return
                }
            print("Weather API URL:", url)
            URLSession.shared.dataTask(with: url) { (data, response, error) in
                guard let data = data else {
                    completion(nil)
                    return
                }

                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode(WeatherForecast.self, from: data)
                    completion(result)
                    print("Decoded Weather Forecast: \(result)")
                } catch {
                    print("Error decoding weather data: \(error.localizedDescription)")
                    completion(nil)
                }
            }.resume()
        }
    }


    struct WeatherForecast: Codable {
        let latitude: Double
        let longitude: Double
        let generationtime_ms: Double
        let timezone: String
        let elevation: Double
        let hourly_units: HourlyUnits
        let hourly: Hourly

        struct HourlyUnits: Codable {
            let time: String
            let temperature_2m: String
            let rain: String
        }
        
        

        struct Hourly: Codable {
            let time: [String]
            let temperature_2m: [Double]
            let rain: [Double]
        }
        
        var maxTemperature: [Double] {
            return hourly.temperature_2m
        }

        var precipitation: [Double] {
            return hourly.rain
        }
    }
