import UIKit

class NetworkManager: NSObject {
    
    struct APIURL {
        
        static func geocodingRequest(forCity name: String) -> String {
            return "https://geocoding-api.open-meteo.com/v1/search?name=\(name)&count=10&language=fr&format=json".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        }
        
        static func weatherForecastRequest(latitude: Double, longitude: Double) -> String {
            return "https://api.open-meteo.com/v1/forecast?latitude=\(latitude)&longitude=\(longitude)&hourly=temperature_2m,rain".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        }
        
    }
        
}
