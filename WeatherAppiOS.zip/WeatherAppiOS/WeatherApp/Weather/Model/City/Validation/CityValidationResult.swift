import Foundation

extension CityValidation {

    struct CityInfo: Codable {
        var id: Int
        var name: String
        var latitude: Double
        var longitude: Double

        enum CodingKeys: String, CodingKey {
            case id
            case name
            case latitude
            case longitude
        }
    }

    struct CityValidationResult: Codable {
        var results: [CityInfo]
        var generationTimeMs: Double

        enum CodingKeys: String, CodingKey {
            case results
            case generationTimeMs = "generationtime_ms"
        }
    }
}
