import UIKit

extension CityValidation {

    struct GeocodingResult: Codable {
        var results: [GeocodingPlace]
        var generationTimeMS: Double
    }

    struct GeocodingPlace: Codable {
        var id: Int
        var name: String
        var latitude: Double
        var longitude: Double

        enum CodingKeys: String, CodingKey {
            case id, name, latitude, longitude
        }
    }

    class func validateCity(withName name: String, _ completion: @escaping (_ places: [GeocodingPlace]) -> Void) {
        guard let url = URL(string: NetworkManager.APIURL.geocodingRequest(forCity: name)) else {
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else {
                completion([])
                return
            }

            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(GeocodingResult.self, from: data)
                completion(result.results)
            } catch {
                print(error.localizedDescription)
                completion([])
            }
        }.resume()
    }
}
