import Foundation

class GeocodingManager: NSObject {
    class func validateCity(withName name: String, _ completion: @escaping (_ places: [GeocodingPlace]) -> Void) {
        guard let url = URL(string: NetworkManager.APIURL.geocodingRequest(forCity: name)) else {
            print("Invalid URL")
            completion([])
            return
        }

        URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard let data = data else {
                completion([])
                return
            }
                            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(GeocodingResult.self, from: data)

                completion(result.results)
            } catch {
                print("Error decoding geocoding result:", error.localizedDescription)
                completion([])
            }
        }.resume()
    }
}

struct GeocodingResult: Codable{
    var results: [GeocodingPlace]
    var generationTimeMS: Double
    
    enum CodingKeys: String, CodingKey {
            case results
            case generationTimeMS = "generationtime_ms"
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            results = try container.decodeIfPresent([GeocodingPlace].self, forKey: .results) ?? []
            generationTimeMS = try container.decode(Double.self, forKey: .generationTimeMS)
        }
}

struct GeocodingPlace: Codable , Identifiable {
    var id: Int
    var name: String
    var latitude: Double
    var longitude: Double

    enum CodingKeys: String, CodingKey {
        case id, name, latitude, longitude
    }
}
