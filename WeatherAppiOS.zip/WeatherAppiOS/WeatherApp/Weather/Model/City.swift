import SwiftUI
import Combine

class City: ObservableObject {
    
    var id: Int 
    var name: String
    var longitude: Double
    var latitude: Double
    
    @Published var weather: WeatherForecast? 
    
    init(id: Int, name: String, latitude: Double, longitude: Double) {
        self.id = id
        self.name = name
        self.longitude = longitude
        self.latitude = latitude
        self.weather = nil
        self.getWeather()
    }
    
    init(name: String, latitude: Double, longitude: Double) {
        self.id = 0
        self.name = name
        self.longitude = longitude
        self.latitude = latitude
        self.weather = nil
        self.getWeather()
    }
    
    private func getWeather() {
        WeatherManager.getWeatherForecast(latitude: self.latitude, longitude: self.longitude) { result in
            DispatchQueue.main.async {
                self.weather = result
                print("Weather data fetched for \(self.name): \(String(describing: self.weather))")
            }
        }
    }

}
