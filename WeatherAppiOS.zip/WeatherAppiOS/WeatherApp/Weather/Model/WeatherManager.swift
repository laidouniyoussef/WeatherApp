//
//  WeatherManager.swift
//  Weather
//
//  Created by Youssef Laidouni on 11/12/2023.
//  Copyright © 2023 Snopia. All rights reserved.
//
import UIKit
import Foundation

class WeatherManager: NSObject {
        
    static func getWeatherForecast(latitude: Double, longitude: Double, completion: @escaping (_ result: WeatherForecast?) -> Void) {
        let url = APIURL.weatherForecastRequest(latitude: latitude, longitude: longitude)
        
        URLSession.shared.dataTask(with: URL(string: url)!) { (data, response, error) in
            guard let data = data else {
                completion(nil)
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode(WeatherForecast.self, from: data)
                completion(result)
            } catch {
                print(error.localizedDescription)
                completion(nil)
            }
        }.resume()
    }
}
